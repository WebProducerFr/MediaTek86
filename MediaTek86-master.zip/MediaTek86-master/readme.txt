Guide téléchargement des versions de l'application

Si vous souhaitez télécharger l'application en version localhost (vous n'aurez pas accès à la base de données, donc vous n'aurez que la fenêtre d'authentification) :
 
	.Il vous faudra pour cela extraire les fichiers du dossier "Téléchargement - MediaTek86 Localhost"
	.Puis vous devrez cliquer sur "setup.exe", et cliquer sur les "ok" des fenêtres qui s'afficheront
	.Enfin vous pourrez lancer l'application à partir de l'application manifeste.

Si vous souhaitez télécharger l'application en version serveur (vous aurez accès à la base de données et donc aux fenêtres de gestion) :
 
	.Il vous faudra pour cela extraire les fichiers du dossier "Téléchargement - MediaTek86 Serveur"
	.Puis vous devrez cliquer sur "setup.exe", et cliquer sur les "ok" des fenêtres qui s'afficheront
	.Enfin vous pourrez lancer l'application à partir de l'application manifeste.

Si vous souhaitez vous connecter sur la fenêtre d'authentification :

	.Il vous faudra saisir l'identifiant : Samzei
	.Il vous faudra saisir le mot de passe : @Azerty85!
